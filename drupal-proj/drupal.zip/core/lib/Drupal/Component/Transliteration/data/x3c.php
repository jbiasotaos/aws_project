<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = [
  0x00 => 'li', 'luo', 'shen', 'mian', 'jian', 'di', 'bei', NULL, 'lian', NULL, 'xian', 'pin', 'que', 'long', 'zui', NULL,
  0x10 => 'jue', 'shan', 'xue', NULL, 'xie', NULL, 'lan', 'qi', 'yi', 'nuo', 'li', 'yue', NULL, 'yi', 'chi', 'ji',
  0x20 => 'hang', 'xie', 'keng', 'zi', 'he', 'xi', 'qu', 'hai', 'xia', 'hai', 'gui', 'chan', 'xun', 'xu', 'shen', 'kou',
  0x30 => 'xia', 'sha', 'yu', 'ya', 'pou', 'zu', 'you', 'zi', 'lian', 'xian', 'xia', 'yi', 'sha', 'yan', 'jiao', 'xi',
  0x40 => 'chi', 'shi', 'kang', 'yin', 'hei', 'yi', 'xi', 'se', 'jin', 'ye', 'you', 'que', 'ye', 'luan', 'kun', 'zheng',
  0x50 => NULL, NULL, NULL, NULL, 'xie', NULL, 'cui', 'xiu', 'an', 'xiu', 'can', 'chuan', 'zha', NULL, 'yi', 'pi',
  0x60 => 'ku', 'sheng', 'lang', 'tui', 'xi', 'ling', 'qi', 'wo', 'lian', 'du', 'men', 'lan', 'wei', 'duan', 'kuai', 'ai',
  0x70 => 'zai', 'hui', 'yi', 'mo', 'zi', 'fen', 'peng', NULL, 'bi', 'li', 'lu', 'luo', 'hai', 'zhen', 'gai', 'que',
  0x80 => 'zhen', 'kong', 'cheng', 'jiu', 'jue', 'ji', 'ling', NULL, 'shao', 'que', 'rui', 'chuo', 'neng', 'zhi', 'lou', 'pao',
  0x90 => NULL, NULL, 'bao', 'rong', 'xian', 'lei', 'xiao', 'fu', 'qu', NULL, 'sha', 'zhi', 'tan', 'rong', 'su', 'ying',
  0xA0 => 'mao', 'nai', 'bian', NULL, 'shuai', 'tang', 'han', 'sao', 'rong', NULL, 'deng', 'pu', 'jiao', 'tan', NULL, 'ran',
  0xB0 => 'ning', 'lie', 'die', 'die', 'zhong', NULL, 'lu', 'dan', 'xi', 'gui', 'ji', 'ni', 'yi', 'nian', 'yu', 'wang',
  0xC0 => 'guo', 'ze', 'yan', 'cui', 'xian', 'jiao', 'tou', 'fu', 'pei', NULL, 'you', 'qiu', 'ya', 'bu', 'bian', 'shi',
  0xD0 => 'zha', 'yi', 'bian', NULL, 'dui', 'lan', 'yi', 'chai', 'chong', 'xuan', 'xu', 'yu', 'xiu', NULL, NULL, NULL,
  0xE0 => 'ta', 'guo', NULL, NULL, NULL, 'long', 'xie', 'che', 'jian', 'tan', 'pi', 'zan', 'xuan', 'xian', 'niao', NULL,
  0xF0 => NULL, NULL, NULL, NULL, 'mi', 'ji', 'nou', 'hu', 'hua', 'wang', 'you', 'ze', 'bi', 'mi', 'qiang', 'xie',
];
